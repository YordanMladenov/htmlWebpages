document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission
    
    // Get form values (email and password)
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    
    console.log("Email:", email, "Password:", password);
    
    // Redirect to another page after sign-in (for example, dashboard.html)
    window.location.href = "https://mcserver.com/complete-auth-signin?redirect=https%3a%2f%2fmcserver.com"; // Replace with your desired URL
});
