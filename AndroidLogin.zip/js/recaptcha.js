// Regular Login Form Submission
document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get form values (email, password)
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    
    // Get reCAPTCHA response
    const recaptchaResponse = grecaptcha.getResponse();

    // Check if reCAPTCHA is successfully completed
    if (recaptchaResponse === "") {
        alert("Please verify that you are not a robot.");
        return; // Exit the function if reCAPTCHA is not solved
    }
    
    console.log("Email:", email, "Password:", password, "reCAPTCHA Response:", recaptchaResponse);
    
    // Redirect to another page after sign-in (for example, dashboard.html)
    window.location.href = "https://mcserver.com/recaptcha-handler?redirect=https%3a%2f%2fmcserver.com%2fcomplete-auth-signin%3fredirect%3dhttps%253a%252f%252fmcserver.com"; // Replace with your desired URL
});